tinyMCE.addI18n('en.code_dlg', {
	title : 'code manager'
});
