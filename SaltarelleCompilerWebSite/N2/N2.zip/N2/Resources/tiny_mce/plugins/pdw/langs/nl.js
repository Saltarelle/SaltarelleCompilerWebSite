tinyMCE.addI18n('nl.pdw',{
	desc : 'Toon/verberg werkbalken'
});
